

 $$$$$$\        $$\                               $$$$$$$\  $$\       $$\       $$\ $$\ $$\ 
$$  __$$\       $$ |                              $$  __$$\ $$ |      $$ |      \__|$$ |\__|
$$ /  $$ | $$$$$$$ | $$$$$$\  $$$$$$\$$$$\        $$ |  $$ |$$ |  $$\ $$$$$$$\  $$\ $$ |$$\ 
$$$$$$$$ |$$  __$$ | \____$$\ $$  _$$  _$$\       $$ |  $$ |$$ | $$  |$$  __$$\ $$ |$$ |$$ |
$$  __$$ |$$ /  $$ | $$$$$$$ |$$ / $$ / $$ |      $$ |  $$ |$$$$$$  / $$ |  $$ |$$ |$$ |$$ |
$$ |  $$ |$$ |  $$ |$$  __$$ |$$ | $$ | $$ |      $$ |  $$ |$$  _$$<  $$ |  $$ |$$ |$$ |$$ |
$$ |  $$ |\$$$$$$$ |\$$$$$$$ |$$ | $$ | $$ |      $$$$$$$  |$$ | \$$\ $$ |  $$ |$$ |$$ |$$ |
\__|  \__| \_______| \_______|\__| \__| \__|      \_______/ \__|  \__|\__|  \__|\__|\__|\__|
                                                                                            
                                                                                            
                                                                                            

Hello and thank you reading!

Contacts Application
----------------------
Setting Up
----------------------
In Command prompt navigate to:
  /adam_dkhili

Enter:
 mvn test

Navigate to /adam_dkhili/backend

Enter:
 mvn spring-boot:run

!!OPEN A SECOND COMMAND PROMPT!!
Navigate to /adam_dkhili/frontend/src/main/frontend

Enter:
 ng serve

----------------------
Using the Application
----------------------
Open a webbrowser and visit http://localhost:4200/contacts