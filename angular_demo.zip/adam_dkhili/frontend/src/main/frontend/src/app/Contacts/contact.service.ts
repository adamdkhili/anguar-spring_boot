import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Contact} from "./contact";
import {Observable, throwError} from "rxjs";
import { retry, catchError } from 'rxjs/operators';

@Injectable()
export class ContactService {
  constructor(private http: HttpClient) {
  }

  // Base url
  baseurl = 'http://127.0.0.1:8080';

  // Http Headers
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  public createContact(data): Observable<Contact[]>{
    console.log( JSON.stringify(data));
    return this.http.post<Contact[]>(this.baseurl + '/rest/newContact', JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  public findContact(data): Observable<Contact[]> {
    return this.http.post<Contact[]>(this.baseurl + '/rest/findContact', JSON.stringify(data),  this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      );
  }

  public getAllContacts(): Observable<Contact[]> {
    return this.http.get<Contact[]>(this.baseurl + '/rest/allContacts', this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      )
  }

  public deleteContact(data): Observable<Contact[]> {
    return this.http.post<Contact[]>(this.baseurl + '/rest/deleteContact', JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      )
  }

  public updateContact(data): Observable<Contact[]> {
    return this.http.put<Contact[]>(this.baseurl + '/rest/updateContact', JSON.stringify(data), this.httpOptions)
      .pipe(
        retry(1),
        catchError(this.errorHandl)
      )
  }

  // Error handling
  errorHandl(error) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    return throwError(errorMessage);
  }

}
