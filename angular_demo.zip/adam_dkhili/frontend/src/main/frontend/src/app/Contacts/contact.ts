export class Contact {

  id: number;
  phoneNumber: string;
  firstName: string;
  lastName: string;
  email: string;

  constructor(
    id: number,
    phoneNumber: string,
    firstName: string,
    lastName: string,
    email: string
  ) {
  }

}
