import {Component, OnInit} from '@angular/core';
import {Contact} from "./contact";
import {ContactService} from "./contact.service";
import {Observable} from "rxjs";

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css']
})
export class ContactsComponent implements OnInit {

  public contacts: Observable<Contact[]>;
  public newContact: Contact;
  public searchContact: Contact;
  public updateContact: Contact;
  public edit: boolean;
  public showResults: boolean;
  public message: string;

  /**@ngInject*/
  constructor(
    private ContactService: ContactService) {
  }

  ngOnInit() {
    this.newContact = {
      firstName: '',
      lastName: '',
      phoneNumber: '',
      email: '',
      id: null
    };
    this.resetSearchForm();
    this.updateContact = {
      firstName: '',
      lastName: '',
      phoneNumber: '',
      email: '',
      id: null
    };
    this.edit = false;
  }

  addContact() {
    if (this.validate(this.newContact)) {
      this.contacts = this.ContactService.createContact(this.newContact);
      this.message = "Contact \"" + this.newContact.firstName + " " + this.newContact.lastName + "\" has been added.";
      this.newContact = {
        firstName: '',
        lastName: '',
        phoneNumber: '',
        email: '',
        id: null
      };
    }
  }

  getAllContacts() {
    this.contacts = this.ContactService.getAllContacts();
    this.showResults = true;
  }

  findContact() {
    this.contacts = this.ContactService.findContact(this.searchContact);
    this.showResults = true;
    this.resetMessage();
  }

  editContact(data: Contact) {
    this.edit = true;
    this.updateContact = data;
  }

  submitUpdate() {
    this.contacts = this.ContactService.updateContact(this.updateContact);
    this.message = "Contact " + this.updateContact.firstName + " " + this.updateContact.lastName + " has been updated.";
    this.edit = false;
  }

  deleteContact(data: Contact) {
    this.contacts = this.ContactService.deleteContact(data);
    this.message = "Contact \"" + data.firstName + " " + data.lastName + "\" has been deleted.";
  }

  resetSearchForm() {
    this.searchContact = {
      firstName: '',
      lastName: '',
      phoneNumber: '',
      email: '',
      id: null
    };
    this.showResults = false;
    this.resetMessage();
  }

  resetMessage() {
    this.message = "";
  }

  validate(data: Contact) {
    if (!(data.firstName.length > 0) || !(data.lastName.length > 0)) {
      this.message = "Invalid Name";
      return false;
    }
    if (!data.phoneNumber.match('^\\D?(\\d{3})\\D?\\D?(\\d{3})\\D?(\\d{4})$')) {
      this.message = "Invalid phone number";
      return false;
    }
    if (!data.email.match('^\\w+[\\w-\\.]*\\@\\w+((-\\w+)|(\\w*))\\.[a-z]{2,3}$')) {
      this.message = "Invalid email";
      return false;
    }
    return true;
  }

}
