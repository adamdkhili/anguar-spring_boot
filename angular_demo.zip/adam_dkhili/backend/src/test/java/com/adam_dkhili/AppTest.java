package com.adam_dkhili;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.adam_dkhili.contact.Contact;
import com.adam_dkhili.controller.ContactController;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import java.util.List;

/**
 * Unit test for simple App.
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AppTest {

    private ContactController conCon = new ContactController();
    private Contact testContact = new Contact(1234, "_testFirstName", "_testLastName", "test@test.com", "123-456-7890");
    private Contact updatedContact = new Contact(1234, "_testFirstName", "_testLastNameUpdated", "updated@test.com", "987-654-3210");

    @Test
    public void _1_addContactAndFind() {
        conCon.createContact(testContact);
        Contact result = conCon.findContactById(1234);
        assertTrue(isEqual(testContact, result));
    }

    @Test
    public void _2_updateContact() {
        conCon.updateContact(updatedContact);
        Contact result = conCon.findContactById(1234);
        assertEquals(updatedContact.getLastName(), result.getLastName());
        assertEquals(updatedContact.getPhoneNumber(), result.getPhoneNumber());
        assertEquals(updatedContact.getEmail(), result.getEmail());
    }

    @Test
    public void _3_deleteContact(){
        List<Contact> contacts = conCon.deleteContact(updatedContact);
        for (Contact contact : contacts){
            if (contact.getId() == 1234){
                assertTrue(false);
            }
        }
    }

    private boolean isEqual(Contact con1, Contact con2) {
        if (con1.getLastName().equals(con2.getLastName())
                && con1.getFirstName().equals(con2.getFirstName())
                && con1.getPhoneNumber().equals(con2.getPhoneNumber())
                && con1.getEmail().equals(con2.getEmail())) {
            return true;
        } else {
            System.out.println(con2.getLastName() + " " + con2.getFirstName());
            return false;
        }
    }
}
