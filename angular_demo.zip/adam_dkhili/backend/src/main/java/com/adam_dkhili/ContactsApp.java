package com.adam_dkhili;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;

@SpringBootApplication(scanBasePackages={"com.adam_dkhili"})
public class ContactsApp {

    public static void main(String[] args) {
        SpringApplication.run(ContactsApp.class, args);
    }
}
