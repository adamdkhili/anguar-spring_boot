package com.adam_dkhili.controller;

import com.adam_dkhili.contact.Contact;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

class ConnectionService {

    private static final String PHONE_NUMBER = "PHONE_NUMBER";
    private static final String EMAIL = "EMAIL";
    private static final String LAST_NAME = "LAST_NAME";
    private static final String FIRST_NAME = "FIRST_NAME";
    private static final String ID = "ID";
    private static final String COLUMNS = "FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER)";

    private Connection getConnection() {
        Connection connection = null;
        String path = System.getProperty("user.dir");
        try {
            // create a database connection
            connection = DriverManager.getConnection("jdbc:sqlite:" + path + "/connections.db");
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS CONTACT (ID integer primary key, FIRST_NAME string, LAST_NAME string, EMAIL string, PHONE_NUMBER string)");
        } catch (Exception e) {
            System.err.println(e.getMessage());
            try {
                connection.close();
            } catch (Exception x) {
                System.err.println(x.getMessage());
            }
        }

        return connection;
    }

    List<Contact> createContact(Contact contact) {
        try {
            Connection connection = getConnection();
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.
            if (contact.getId() == 0){
                statement.executeUpdate(String.format("INSERT INTO CONTACT (" + COLUMNS +
                        " VALUES ('%s', '%s', '%s', '%s')", contact.getFirstName(), contact.getLastName(), contact.getEmail(), contact.getPhoneNumber()));
            } else {
                statement.executeUpdate(String.format("INSERT INTO CONTACT (ID, " + COLUMNS +
                        " VALUES ('%d', '%s', '%s', '%s', '%s')", contact.getId(), contact.getFirstName(), contact.getLastName(), contact.getEmail(), contact.getPhoneNumber()));
            }
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return getAllContacts();
    }

    List<Contact> getAllContacts() {
        Connection connection = getConnection();
        List<Contact> results = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.
            ResultSet rs = statement.executeQuery("SELECT * from CONTACT");
            while (rs.next()) {
                results.add(new Contact(rs.getInt(ID), rs.getString(FIRST_NAME), rs.getString(LAST_NAME), rs.getString(EMAIL), rs.getString(PHONE_NUMBER)));
            }
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return results;
    }

    List<Contact> findContact(Contact contact) {
        Connection connection = getConnection();
        List<Contact> results = new ArrayList<>();
        try {
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.
            ResultSet rs;
            if(contact.getFirstName().equals("") || contact.getLastName().equals("")){
                rs = statement.executeQuery(String.format("SELECT * from CONTACT WHERE FIRST_NAME = '%s' OR LAST_NAME = '%s'", contact.getFirstName(), contact.getLastName()));
            } else{

                rs = statement.executeQuery(String.format("SELECT * from CONTACT WHERE FIRST_NAME = '%s' AND LAST_NAME = '%s'", contact.getFirstName(), contact.getLastName()));
            }
            while (rs.next()) {
                results.add(new Contact(rs.getInt(ID), rs.getString(FIRST_NAME), rs.getString(LAST_NAME), rs.getString(EMAIL), rs.getString(PHONE_NUMBER)));
            }
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return results;
    }

    List<Contact> deleteContact(Contact contact) {
        Connection connection = getConnection();
        try {
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.
            statement.executeUpdate(String.format("DELETE FROM CONTACT WHERE ID = '%d'", contact.getId()));
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return getAllContacts();
    }

    public List<Contact> updateContact(Contact contact) {
        Connection connection = getConnection();
        try {
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.
            statement.executeUpdate(String.format(
                    "UPDATE CONTACT " +
                            "SET LAST_NAME = '%s', " +
                            "PHONE_NUMBER = '%s', " +
                            "EMAIL = '%s' " +
                            "WHERE ID = '%d'",
                    contact.getLastName(), contact.getPhoneNumber(), contact.getEmail(), contact.getId()));
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return findContact(contact);
    }

    public Contact findById(int id) {
        Connection connection = getConnection();
        Contact result = new Contact();
        try {
            Statement statement = connection.createStatement();
            statement.setQueryTimeout(30);  // set timeout to 30 sec.
            ResultSet rs = statement.executeQuery(String.format("SELECT * from CONTACT WHERE ID = '%d'", id));
            while (rs.next()) {
                result = new Contact(rs.getInt(ID), rs.getString(FIRST_NAME), rs.getString(LAST_NAME), rs.getString(EMAIL), rs.getString(PHONE_NUMBER));
            }
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return result;
    }
}
