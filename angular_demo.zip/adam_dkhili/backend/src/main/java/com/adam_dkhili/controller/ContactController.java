package com.adam_dkhili.controller;

import com.adam_dkhili.contact.Contact;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/rest")
public class ContactController {

    ConnectionService connectionService = new ConnectionService();

    @PostMapping(path = "/newContact")
    public List<Contact> createContact(@RequestBody Contact contact){
        return connectionService.createContact(contact);
    }

    @GetMapping(path = "/allContacts")
    public List<Contact> getAllContacts() {
        return connectionService.getAllContacts();
    }

    @PostMapping(path = "/findContact")
    public List<Contact> findContacts(@RequestBody Contact contact) {
        return connectionService.findContact(contact);
    }

    @PostMapping(path = "/deleteContact")
    public List<Contact> deleteContact(@RequestBody Contact contact) {
        return connectionService.deleteContact(contact);
    }

    @PutMapping(path = "/updateContact")
    public List<Contact> updateContact(@RequestBody Contact contact) {
        return connectionService.updateContact(contact);
    }

    //Only used for testing
    public Contact findContactById(int id) {
        return connectionService.findById(id);
    }
}
